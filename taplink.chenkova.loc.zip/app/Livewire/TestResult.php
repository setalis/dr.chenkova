<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\TestSession;

class TestResult extends Component
{
    public TestSession $session;
    public string $resultCode = '';
    public string $email = '';

    public function mount(TestSession $session)
    {
        \Log::info('TestResult component mounted', [
            'session_id' => $session->id,
            'skin_type_code' => $session->skin_type_code
        ]);
        
        $this->session = $session;
        $this->calculateResult();
        
        \Log::info('TestResult calculation completed', [
            'result_code' => $this->resultCode
        ]);
    }

    public function calculateResult()
    {
        $code = '';
        $code .= $this->axisResult($this->session->test_one_answers, 'D');
        $code .= $this->axisResult($this->session->test_two_answers, 'S');
        $code .= $this->axisResult($this->session->test_three_answers, 'N');
        $code .= $this->axisResult($this->session->test_four_answers, 'T');
        $this->resultCode = $code;
        $this->session->update(['skin_type_code' => $code]);
    }

    private function axisResult($answers, $axis)
    {
        $sum = collect($answers)->map(fn($v) => floatval($v))->sum();

        return match ($axis) {
            'D' => $sum <= 30 ? 'D' : 'O',
            'S' => $sum <= 35 ? 'S' : 'R',
            'N' => $sum <= 35 ? 'N' : 'P', // P как "Pigmented"
            'T' => $sum <= 40 ? 'T' : 'W',
            default => '?',
        };
    }

    public function sendEmail()
    {
        \Log::info('Sending results via email and telegram', [
            'email' => $this->email,
            'result_code' => $this->resultCode
        ]);

        // Отправка на email
        \Mail::send('emails.test-result', [
            'resultCode' => $this->resultCode,
            'session' => $this->session
        ], function ($message) {
            $message->to($this->email)
                    ->subject('Ваш результат теста по типу кожи');
        });

        // Отправка в Telegram
        $telegramMessage = "Новый результат теста!\n\n";
        $telegramMessage .= "Email: {$this->email}\n";
        $telegramMessage .= "Тип кожи: {$this->resultCode}\n";
        $telegramMessage .= "D/O: " . ($this->resultCode[0] === 'D' ? 'Сухая' : 'Жирная') . "\n";
        $telegramMessage .= "S/R: " . ($this->resultCode[1] === 'S' ? 'Чувствительная' : 'Резистентная') . "\n";
        $telegramMessage .= "N/P: " . ($this->resultCode[2] === 'N' ? 'Непигментированная' : 'Пигментированная') . "\n";
        $telegramMessage .= "T/W: " . ($this->resultCode[3] === 'T' ? 'Упругая' : 'Морщинистая') . "\n";

        $this->sendToTelegram($telegramMessage);

        session()->flash('message', 'Результат отправлен на email и в Telegram!');
    }

    private function sendToTelegram($message)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        if (!$botToken || !$chatId) {
            \Log::error('Telegram configuration missing', [
                'bot_token_exists' => !empty($botToken),
                'chat_id_exists' => !empty($chatId)
            ]);
            return;
        }

        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        try {
            $response = \Http::post($url, $data);
            
            \Log::info('Telegram message sent', [
                'status' => $response->status(),
                'response' => $response->json()
            ]);
        } catch (\Exception $e) {
            \Log::error('Failed to send Telegram message', [
                'error' => $e->getMessage()
            ]);
        }
    }

    public function render()
    {
        return view('livewire.test-result')->layout('components.layouts.front-livewire');
    }
}
