<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Тесты')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <!-- <?php echo app('flux')->fluxAppearance(); ?> -->
</head> 
<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        <?php if (isset($component)) { $__componentOriginal07a90ab6ff353cc67cef9e6d27d14a6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07a90ab6ff353cc67cef9e6d27d14a6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.partials.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.partials.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07a90ab6ff353cc67cef9e6d27d14a6b)): ?>
<?php $attributes = $__attributesOriginal07a90ab6ff353cc67cef9e6d27d14a6b; ?>
<?php unset($__attributesOriginal07a90ab6ff353cc67cef9e6d27d14a6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07a90ab6ff353cc67cef9e6d27d14a6b)): ?>
<?php $component = $__componentOriginal07a90ab6ff353cc67cef9e6d27d14a6b; ?>
<?php unset($__componentOriginal07a90ab6ff353cc67cef9e6d27d14a6b); ?>
<?php endif; ?>
        
        <main>
            <?php echo e($slot); ?>

        </main>

        <?php if (isset($component)) { $__componentOriginalff0febf07c7a9e05cdc70e369c825961 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff0febf07c7a9e05cdc70e369c825961 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.partials.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.partials.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff0febf07c7a9e05cdc70e369c825961)): ?>
<?php $attributes = $__attributesOriginalff0febf07c7a9e05cdc70e369c825961; ?>
<?php unset($__attributesOriginalff0febf07c7a9e05cdc70e369c825961); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff0febf07c7a9e05cdc70e369c825961)): ?>
<?php $component = $__componentOriginalff0febf07c7a9e05cdc70e369c825961; ?>
<?php unset($__componentOriginalff0febf07c7a9e05cdc70e369c825961); ?>
<?php endif; ?>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <!-- <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?> -->
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
</body>
</html> <?php /**PATH H:\OSPanel\home\taplink.chenkova.loc\resources\views/components/layouts/app/frontend.blade.php ENDPATH**/ ?>